
<?php $__env->startSection('title', 'Pagina inicial'); ?>
<?php $__env->startSection('conteudo'); ?>
<div class="row contaier">
    <h4><?php echo e($categoria->nome); ?> </h4>
    <?php $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
    <div class="col s12 m4">
        <div class="card ">
            <div class="card-image">
              <img src="<?php echo e($produto->imagem); ?>">
              <a href="<?php echo e(route('site.details', $produto->slug)); ?>" class="btn-floating halfway-fab waves-effect waves-light red"><i class="material-icons">visibility</i></a>
            </div>
            <div class="card-content">
                <span class="card-title"><?php echo e(Str::limit($produto->nome,20)); ?></span>
              <p><?php echo e(Str::limit($produto->descricao,35)); ?></p>
            </div>
          </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="row container center">
    <?php echo e($produtos->links('custom.pagination')); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cursolaravel\resources\views/site/categoria.blade.php ENDPATH**/ ?>