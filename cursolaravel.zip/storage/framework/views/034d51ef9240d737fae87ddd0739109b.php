
<?php $__env->startSection('title', 'Carrinho'); ?>
<?php $__env->startSection('conteudo'); ?>
<div class="row contaier">

  <?php if($mensagem = Session::get('sucesso')): ?>
      <div class="card green darken-1">
        <div class="card-content white-text">
          <span class="card-title">Parabéns:</span>
          <p><?php echo e($mensagem); ?></p>
        </div>
      </div>
    <?php endif; ?>
    <?php if($mensagem = Session::get('aviso')): ?>
      <div class="card red darken-1">
        <div class="card-content white-text">
          <span class="card-title">=/</span>
          <p><?php echo e($mensagem); ?></p>
        </div>
      </div>
    <?php endif; ?>
    <?php if($itens->count()== 0): ?>
    <div class="card pink darken-1">
      <div class="card-content white-text">
        <span class="card-title">Carrinho vazio.</span>
        <p>Adicione algo ao seu carrinho.</p>
      </div>
    </div>
        <?php else: ?>
        <h4>Seu Carrinho possui: <?php echo e($itens->count()); ?> produtos.</h4>
        <table class="striped">
            <thead>
              <tr>
                  <th></th>
                  <th>Nome</th>
                  <th>Preço</th>
                  <th>Quantidade</th>
                  <th></th>
              </tr>
            </thead>
    
            <tbody>
                <?php $__currentLoopData = $itens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><img src="<?php echo e($item->attributes->image); ?>" alt="" width="70" class="responsiv-img circle"></td>
                            <td><?php echo e($item->name); ?></td>
                            <td>R$ <?php echo e(number_format($item->price,2,',','.')); ?></td>
                              
                            <form action="<?php echo e(route('site.atualizacarrinho')); ?>" method="POST" enctype="multipart/form-data" >
                                  <?php echo csrf_field(); ?>
                                  <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                                <td><input style="width: 40px" class="white center" type="number" name="quantity" min="1" value="<?php echo e($item->quantity); ?>"></td>
                                <td>
                                    <button class="btn-floating waves-effect waves-light pink"><i class="material-icons">refresh</i></button>
                              </form>    
                                <form action="<?php echo e(route('site.removecarrinho')); ?>" method="POST" enctype="multipart/form-data" >
                                    <?php echo csrf_field(); ?>
                                  <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                                    <button class="btn-floating waves-effect waves-light red"><i class="material-icons">delete</i></button>
                                </form>
                            </td>
                          </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </tbody>
          </table>
          
          <div class="card pink">
            <div class="card-content white-text">
              <span class="card-title" style="text-align: right">R$ <?php echo e(number_format(\Cart::getTotal(),2,',','.')); ?></span>
              <p style="text-align: right">Em até 12x Sem juros*</p>
            </div>
          </div>
    <?php endif; ?>

   
    
<div class="row container center">
    <a href="<?php echo e(route('site.index')); ?>" class="btn large waves-effect waves-light pink">Continuar comprando<i class="material-icons right">arrow_back</i></button>
    <a href="<?php echo e(route('site.limparcarrinho')); ?>" class="btn large waves-effect waves-light pink">Limpar carrinho<i class="material-icons right">clear</i></a>
    <button class="btn large waves-effect waves-light pink">Finalizar pedido<i class="material-icons right">check</i></button>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cursolaravel\resources\views/site/carrinho.blade.php ENDPATH**/ ?>