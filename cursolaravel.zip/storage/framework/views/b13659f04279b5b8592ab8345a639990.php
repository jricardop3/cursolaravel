<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=,, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body style="display: flex;
min-height: 100vh;
flex-direction: column;">

  
  <header>
    <nav class="pink"> <!-- inicio menu -->
        <div class="nav-wrapper">
          <a href="<?php echo e(route('site.index')); ?>" class="hide-on-small-only" class="brand-logo">Estudando Laravel</a>
           <ul id="nav-mobile" class="left">
            <li><a href="<?php echo e(route('site.index')); ?>" >Home</a></li>
            <li class="hide-on-small-only"><a href="#" class='dropdown-trigger' data-target='dropdown1'>Categoria<i class="material-icons right">expand_more</i></a></li>
            <li  class="show-on-small hide-on-med-and-up"><a href="#" class='dropdown-trigger' data-target='dropdown1'>Cat...<i class="material-icons right">expand_more</i></a></li>
            <ul id='dropdown1' class='dropdown-content'>
              <?php $__currentLoopData = $categoriasMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoriaM): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <li><a href="<?php echo e(route('site.categoria', $categoriaM->id)); ?>"><?php echo e($categoriaM->nome); ?></a></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <li class="hide-on-small-only"><a href="<?php echo e(route('site.carrinho')); ?>">Carrinho<span class="new badge pink" data-badge-caption=""><?php echo e($itens = \Cart::getContent()->count()); ?></span></a></li>
         </ul>
         <?php if(auth()->guard()->check()): ?>
         <ul id="nav-mobile" class="right">
          <span><li><a href="#" class='dropdown-trigger' data-target='dropdown2'>Olá <?php echo e(auth()->user()->firstName); ?><i class="tiny material-icons right">expand_more</i></a></li></span>
         </ul>
         <?php else: ?>
         <ul id="nav-mobile" class="right">
          <span><li><a href="<?php echo e(route('login.form')); ?>">Entrar<i class="material-icons right">elocked</i></a></li></span>
         </ul>
         <?php endif; ?>
         <ul id='dropdown2' class='dropdown-content'>
            <li><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
            <li><a href="<?php echo e(route('login.logout')); ?>">Sair</a></li>         
        </ul>
        
        </div>
      </nav><!-- fim menu -->
  </header>
  <main style="flex: 1 0 auto;">
    <?php echo $__env->yieldContent('conteudo'); ?>
  </main>
  <footer  class="page-footer pink ">
      <div class="row">
        <div class="col s12 center">
          <h5 class="white-text">© Todos os direitos Reservados a <a class="white-text" href="http://spgweb.com.br">Script Praia Grande Web</a></h5>
        </div>
      </div>
  </footer>
<!-- Compiled and minified JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
<script>
  var elemDrop = document.querySelectorAll('.dropdown-trigger');
  var instanceDrop = M.Dropdown.init(elemDrop, {
    converTrigger: false,
    constrainWidth: false
  });
</script>
</body>
</html><?php /**PATH C:\laragon\www\cursolaravel\resources\views/site/layout.blade.php ENDPATH**/ ?>