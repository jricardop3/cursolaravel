<?php if($mensagem = Session::get('erro')): ?>
<?php echo e($mensagem); ?>

<?php endif; ?>
<?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($error); ?><br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
<?php endif; ?>
<form action="<?php echo e(route('login.auth')); ?>" method="GET">
<?php echo csrf_field(); ?>
Email: <br><input type="email" value="sac@spgweb.com.br" name="email" id="">
<input type="password" value="" name="password" id="">
<input type="checkbox" name="remember">Lembre-me
<button type="submit">Entrar</button>
</form><?php /**PATH C:\laragon\www\cursolaravel\resources\views/login/form.blade.php ENDPATH**/ ?>