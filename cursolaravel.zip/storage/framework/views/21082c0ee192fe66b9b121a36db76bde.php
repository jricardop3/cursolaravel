<?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($error); ?><br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<form action="<?php echo e(route('users.store')); ?>" method="POST">
<?php echo csrf_field(); ?>
Nome: <input type="text" name="firstName" id=""><br>
Sobrenome: <input type="text" name="lastName" id=""><br>
Email: <input type="email" value="sac@spgweb.com.br" name="email" id=""><br>
Senha: <input type="password" value="" name="password" id=""><br>
<button type="submit">Cadastrar</button>
</form><?php /**PATH C:\laragon\www\cursolaravel\resources\views/login/create.blade.php ENDPATH**/ ?>